from marshmallow import Schema, fields

class RegisterSchema(Schema):
    username = fields.Str(required=True)
    email = fields.Email(required=True)
    password = fields.Str(required=True)

class LoginSchema(Schema):
    username = fields.Str(required=True)
    password = fields.Str(required=True)

class TelemetrySchema(Schema):
    sat_id = fields.Str(required=True)
    raw_payload = fields.Str(required=True)
    signal_strength = fields.Float()
    noise_floor = fields.Float()
    packet_loss_ratio = fields.Float()
