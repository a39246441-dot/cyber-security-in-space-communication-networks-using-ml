import random

def simulate_bb84(num_bits=128, eavesdrop=False):
    alice_bits = [random.randint(0,1) for _ in range(num_bits)]
    alice_bases = [random.choice(['Z','X']) for _ in range(num_bits)]
    bob_bases = [random.choice(['Z','X']) for _ in range(num_bits)]

    bob_bits = []
    for i in range(num_bits):
        if alice_bases[i] == bob_bases[i]:
            bit = alice_bits[i]
            if eavesdrop and random.random() < 0.1:
                bit = 1-bit
            bob_bits.append(bit)
        else:
            bob_bits.append(random.randint(0,1))

    key_indices = [i for i in range(num_bits) if alice_bases[i] == bob_bases[i]]
    alice_key = [alice_bits[i] for i in key_indices]
    bob_key = [bob_bits[i] for i in key_indices]

    errors = sum(1 for a,b in zip(alice_key, bob_key) if a!=b)
    qber = (errors / max(1,len(alice_key)))
    final_key = ''.join(str(b) for b in bob_key[:max(1,len(bob_key)//2)])
    return {'shared_secret_key': final_key, 'qber': round(qber,4), 'eavesdropper_detected': qber>0.1}
