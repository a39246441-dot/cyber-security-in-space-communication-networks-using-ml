from flask import Flask, request, jsonify
from config import Config
from extensions import db, migrate, jwt
from models import User, Satellite, Telemetry
from schemas import RegisterSchema, LoginSchema, TelemetrySchema
from crypto_utils import generate_rsa_keypair, verify_signature
from jam_detector import detect_jamming
from qkd_sim import simulate_bb84
from blockchain_stub import log_to_ledger, get_ledger
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
migrate.init_app(app, db)
jwt.init_app(app)

@app.route('/api/health')
def health():
    return jsonify({'status':'ok'})

@app.route('/api/auth/register', methods=['POST'])
def register():
    schema = RegisterSchema()
    data = schema.load(request.json)
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'msg':'username exists'}), 400
    user = User(
        username=data['username'],
        email=data['email'],
        password_hash=generate_password_hash(data['password'])
    )
    db.session.add(user)
    db.session.commit()
    return jsonify({'msg':'registered'}), 201

@app.route('/api/auth/login', methods=['POST'])
def login():
    schema = LoginSchema()
    data = schema.load(request.json)
    user = User.query.filter_by(username=data['username']).first()
    if not user or not check_password_hash(user.password_hash, data['password']):
        return jsonify({'msg':'bad credentials'}), 401
    token = create_access_token(identity=user.id)
    return jsonify({'access_token': token}), 200

@app.route('/api/satellite/register', methods=['POST'])
@jwt_required()
def register_sat():
    user_id = get_jwt_identity()
    json_data = request.json
    sat_id = json_data.get('sat_id')
    if Satellite.query.filter_by(sat_id=sat_id).first():
        return jsonify({'msg':'satellite exists'}), 400
    priv, pub = generate_rsa_keypair()
    sat = Satellite(sat_id=sat_id, owner_id=user_id, certificate=pub, fingerprint='sha256:'+pub[:64])
    db.session.add(sat)
    db.session.commit()
    tx = log_to_ledger({'action':'sat_register','sat_id':sat_id, 'pub':pub[:80]})
    return jsonify({'sat_id':sat_id, 'public_key': pub, 'ledger_tx': tx}), 201

@app.route('/api/telemetry', methods=['POST'])
@jwt_required()
def telemetry_ingest():
    schema = TelemetrySchema()
    data = schema.load(request.json)
    telem = Telemetry(sat_id=data['sat_id'], raw_payload=data['raw_payload'])
    db.session.add(telem)
    db.session.commit()

    signal_strength = data.get('signal_strength', 0)
    noise_floor = data.get('noise_floor', 0)
    packet_loss_ratio = data.get('packet_loss_ratio', 0)
    jam = detect_jamming(signal_strength, noise_floor, packet_loss_ratio)

    tx = log_to_ledger({'action':'telemetry_ingest','sat_id':data['sat_id'],'jam':jam})
    return jsonify({'msg':'stored','jam_detection': jam, 'ledger_tx': tx}), 201

@app.route('/api/command/verify', methods=['POST'])
@jwt_required()
def verify_command():
    body = request.json
    sat_id = body['sat_id']
    signature_hex = body['signature']
    payload = body['payload']
    sat = Satellite.query.filter_by(sat_id=sat_id).first()
    if not sat:
        return jsonify({'msg':'sat not found'}), 404
    ok = verify_signature(sat.certificate, payload.encode(), bytes.fromhex(signature_hex))
    tx = log_to_ledger({'action':'command_verify','sat_id':sat_id,'ok':ok})
    return jsonify({'verified': ok, 'ledger_tx': tx}), 200

@app.route('/api/qkd/simulate', methods=['GET'])
@jwt_required()
def qkd_sim():
    eavesdrop = request.args.get('eavesdrop', 'false').lower()=='true'
    res = simulate_bb84(256, eavesdrop=eavesdrop)
    tx = log_to_ledger({'action':'qkd_sim','res':{'qber':res['qber']}})
    return jsonify({'qkd': res, 'ledger_tx': tx})

@app.route('/api/ledger', methods=['GET'])
@jwt_required()
def ledger():
    return jsonify(get_ledger())

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
