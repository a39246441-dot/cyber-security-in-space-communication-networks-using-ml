from extensions import db
from datetime import datetime

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Satellite(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sat_id = db.Column(db.String(128), unique=True, nullable=False)
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    certificate = db.Column(db.Text)
    fingerprint = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Telemetry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sat_id = db.Column(db.String(128), nullable=False)
    raw_payload = db.Column(db.Text)
    received_at = db.Column(db.DateTime, default=datetime.utcnow)

class BlockchainLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tx_hash = db.Column(db.String(256))
    payload = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
