import hashlib, json
from datetime import datetime

ledger = []

def log_to_ledger(payload: dict):
    tx = {
        'timestamp': datetime.utcnow().isoformat(),
        'payload': payload,
    }
    tx_json = json.dumps(tx, sort_keys=True).encode()
    tx_hash = hashlib.sha256(tx_json).hexdigest()
    tx['tx_hash'] = tx_hash
    ledger.append(tx)
    return tx

def get_ledger():
    return ledger
