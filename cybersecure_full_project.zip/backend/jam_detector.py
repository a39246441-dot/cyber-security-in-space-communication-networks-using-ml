def detect_jamming(signal_strength, noise_floor, packet_loss_ratio, spectrum_entropy=None):
    score = 0.0
    if signal_strength and signal_strength > 100:
        score += 0.4
    if packet_loss_ratio and packet_loss_ratio > 0.1:
        score += 0.4
    if noise_floor and noise_floor > 30:
        score += 0.2
    return {'jammer_detection_flag': score >= 0.6, 'confidence_score': round(score,2)}
