# Cybersecure Space Communication — Prototype

This project is a prototype full-stack application demonstrating a cybersecure space communication system.
It includes a Flask backend and React frontend.

## Backend (Flask)
- Run in a Python 3.10+ environment
- Install:
    pip install -r backend/requirements.txt
- Initialize DB (optional):
    from backend import app
    with app.app_context():
        from extensions import db
        db.create_all()
- Run:
    python backend/app.py

## Frontend (React)
- cd frontend
- npm install
- npm start

The frontend expects the backend at http://127.0.0.1:5000/api
