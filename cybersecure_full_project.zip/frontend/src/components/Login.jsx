import { useState } from "react";
import { loginUser } from "../api";
export default function Login({ onLogin, onSwitch }) {
  const [form, setForm] = useState({ username:'', email: "", password: ""});
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await loginUser(form);
      const token = res.data.access_token || res.data.token;
      if(token){
        onLogin(token);
      } else {
        alert('Login failed');
      }
    } catch (err) {
      alert("Invalid login");
    }
  };
  return (
    <div className="container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Username" onChange={(e) => setForm({ ...form, username: e.target.value })} /><br /><br />
        <input type="password" placeholder="Password" onChange={(e) => setForm({ ...form, password: e.target.value })} /><br /><br />
        <button type="submit">Login</button>
      </form>
      <p>Don’t have an account? <span style={{ color: "blue", cursor: "pointer" }} onClick={onSwitch}>Register</span></p>
    </div>
  );
}
