import { useState } from "react";
import { registerUser } from "../api";
export default function Register({ onSwitch }) {
  const [form, setForm] = useState({ username:'', email: "", password: ""});
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await registerUser(form);
      alert("Registration successful!");
      onSwitch();
    } catch (err) {
      alert("Registration failed");
    }
  };
  return (
    <div className="container">
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Username" onChange={(e) => setForm({ ...form, username: e.target.value })} /><br /><br />
        <input placeholder="Email" onChange={(e) => setForm({ ...form, email: e.target.value })} /><br /><br />
        <input type="password" placeholder="Password" onChange={(e) => setForm({ ...form, password: e.target.value })} /><br /><br />
        <button type="submit">Register</button>
      </form>
      <p>Already have an account? <span style={{color:'blue', cursor:'pointer'}} onClick={onSwitch}>Login</span></p>
    </div>
  );
}
