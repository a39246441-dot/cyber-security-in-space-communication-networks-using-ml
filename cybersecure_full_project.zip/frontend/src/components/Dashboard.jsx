import { useEffect, useState } from "react";
import { fetchEncryptedPackets, fetchAlerts } from "../api";
export default function Dashboard({ token }) {
  const [packets, setPackets] = useState([]);
  const [alerts, setAlerts] = useState([]);
  useEffect(() => {
    fetchEncryptedPackets().then((res) => setPackets(res.data.packets || []));
    fetchAlerts().then((res) => setAlerts(res.data.alerts || []));
  }, []);
  return (
    <div className="container">
      <h1>Satellite Security Dashboard</h1>
      <h3>Encrypted Packets</h3>
      <ul>
        {packets.map((p, idx) => (<li key={idx}>{p}</li>))}
      </ul>
      <h3>Security Alerts</h3>
      <ul>
        {alerts.map((a, idx) => (<li key={idx} style={{ color: "red" }}>⚠️ {a}</li>))}
      </ul>
    </div>
  );
}
