import { useState } from "react";
import Login from "./components/Login";
import Register from "./components/Register";
import Dashboard from "./components/Dashboard";
export default function App() {
  const [token, setToken] = useState(null);
  const [showRegister, setShowRegister] = useState(false);
  if (!token) {
    return showRegister ? (
      <Register onSwitch={() => setShowRegister(false)} />
    ) : (
      <Login onLogin={setToken} onSwitch={() => setShowRegister(true)} />
    );
  }
  return <Dashboard token={token} />;
}
