import axios from "axios";
const API = axios.create({
  baseURL: "http://127.0.0.1:5000/api",
});
export const registerUser = (data) => API.post("/auth/register", data);
export const loginUser = (data) => API.post("/auth/login", data);
export const fetchEncryptedPackets = () => API.get("/secure/packets").catch(()=>({data:{packets:[]}}));
export const fetchAlerts = () => API.get("/alerts").catch(()=>({data:{alerts:[]}}));
export default API;
